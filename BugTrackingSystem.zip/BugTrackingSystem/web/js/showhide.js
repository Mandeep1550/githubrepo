function showmenu(m)
{
	document.getElementById(m).style.visibility="visible";
}
function hidemenu(m)
{
	document.getElementById(m).style.visibility="hidden";
}