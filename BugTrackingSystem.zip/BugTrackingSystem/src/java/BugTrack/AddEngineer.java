/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BugTrack;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 *
 * @author user
 */
@MultipartConfig
public class AddEngineer extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();
         int res;   
    Statement st;
    Connection con=null;
        //int id=Integer.parseInt(request.getParameter("id"))
        String uid=request.getParameter("id");
        String ename=request.getParameter("ename");
        
        String email=request.getParameter("email");
        String pass=request.getParameter("password");
        String dob=request.getParameter("year")+"-"+request.getParameter("month")+"-"+request.getParameter("day");
        String mob=request.getParameter("mobile");
        String gen=request.getParameter("gen");
        String add=request.getParameter("address");
        String pin=request.getParameter("pincode");
        String etype=request.getParameter("engtype");
        
      
        con=ConnectClass.coonect();
         InputStream inputStream=null; //input stream of the upload file
          Part filePart=request.getPart("img");
        if(filePart!=null)
        {
             inputStream=filePart.getInputStream();   
        }
      
        String message=null;
        try
        {
          
          String sql = "insert into engineer_detail values(?,?,?,?,?,?,?,?,?,?,?)";
          PreparedStatement pr=con.prepareStatement(sql);
          pr.setInt(1, Integer.parseInt(uid));
          pr.setString(2, ename);
          pr.setString(3, email);
          pr.setString(4, pass);
          pr.setString(5, dob);
          pr.setString(6, mob);
          pr.setString(7, gen);
          pr.setString(8, add);
          pr.setString(9, pin);
         
          if(inputStream !=null)
          {
              pr.setBlob(10, inputStream);
          }
          pr.setString(11, etype);
          int row=pr.executeUpdate();
          if(row>0)
          {
          DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	   //get current date time with Date()
	   Date date = new Date();
          
          String subject="Regarding registration with CheckEdu";
          String msg="Congratulations "+ename+", You have successfully registered with our company on "+dateFormat.format(date)+".\n \nYour User id:"+email+"\n Your Password:"+pass+"\n\n\n Regards,\n BugSystem";
          Mailer.send(email, subject, msg);
           out.write("<script> window.alert('Registration complete successfully'); window.location='Register.jsp';</script>") ; 
          }
        else
        {
             out.write("<script> window.alert('Registration not complete '); window.location='Register.jsp';</script>") ;  
        }
        
        }
        catch(Exception e)
        {
            message=e.getMessage();
        }
        finally
        {
            if(con!=null)
            {
                try
                {
                    con.close();
                    
                }
                catch(SQLException ex)
                {
                }
            }
            PrintWriter o=response.getWriter();
            o.print(message);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
