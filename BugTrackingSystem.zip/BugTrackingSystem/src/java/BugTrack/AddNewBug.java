/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BugTrack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author user
 */
public class AddNewBug extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out=response.getWriter();
        String message=null;
       String bid=request.getParameter("bid");
        String bname=request.getParameter("bname");
        String desc=request.getParameter("desc");
        String prior=request.getParameter("prior");
       String duedate=request.getParameter("year")+"-"+request.getParameter("month")+"-"+request.getParameter("day");
        
        String peng=request.getParameter("pe");
          String seng=request.getParameter("se");
          Connection con=ConnectClass.coonect();
           try
        {
          
          String sql = "insert into bug_detail values(?,?,?,?,?,?,?,?)";
          PreparedStatement pr=con.prepareStatement(sql);
          pr.setInt(1, Integer.parseInt(bid));
          pr.setString(2, bname);
          pr.setString(3, desc);
          pr.setInt(4, Integer.parseInt(prior));
          pr.setString(5, duedate);
          pr.setString(6, "Not Resolved");
          pr.setString(7, peng);
          pr.setString(8,seng);
         
          int row=pr.executeUpdate();
          if(row>0)
          {
              Statement st;
              st=con.createStatement();
               ResultSet res=null;
               String pengname=null,email=null;
              try
              {
                      res=st.executeQuery("select name,email from engineer_detail where eng_id="+peng); 
                      
                        }
                         catch(Exception e)                               
                         {
                         }
                       if(res.next())
                       {
                        pengname=res.getString(1);   
                        email=res.getString(2);
                       }
          DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	   //get current date time with Date()
	   Date date = new Date();
        
          String subject="Regarding Bug Found in Project";
          String msg="Hi "+pengname+", This is to inform you that bug has been found in your project on "+dateFormat.format(date)+".Please Resolve it ASAP.\n\n\n Regards,\n BugSystem";
          Mailer.send(email, subject, msg);
           out.write("<script> window.alert('New Bug Added successfully'); window.location='AddNewBug.jsp';</script>") ; 
          }
        else
        {
             out.write("<script> window.alert('Bug has not been Added '); window.location='AddNewBug.jsp';</script>") ;  
        }
        
        }
        catch(Exception e)
        {
            message=e.getMessage();
        }
        finally
        {
            if(con!=null)
            {
                try
                {
                    con.close();
                    
                }
                catch(SQLException ex)
                {
                }
            }
            PrintWriter o=response.getWriter();
            o.print(message);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
