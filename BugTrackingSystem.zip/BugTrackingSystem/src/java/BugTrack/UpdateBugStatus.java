/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BugTrack;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author user
 */
public class UpdateBugStatus extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
          
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       PrintWriter out=response.getWriter();
        String message=null,sql=null;
        Statement st=null;
       String status=request.getParameter("status");
       int bid=Integer.parseInt(request.getParameter("id"));
       sql="update bug_detail set status='"+status+"'where bug_id="+bid; 
       Connection con=ConnectClass.coonect();
       try
       {
           st=con.createStatement();
           int res=st.executeUpdate(sql);
           if(res>0)
                   {
        out.print("<script>");
          out.print("var msg='Bug Status has been Updated.';");
           out.print("document.getElementById('msg').innerHTML=msg.fontcolor('green').bold();");
            out.print("</script>");
               RequestDispatcher rd=request.getRequestDispatcher("UpdateBug.jsp");
			rd.include(request, response);
                 }
    else
               {
         out.print("<script>");
            out.print("var msg='Bug Status has not been changed.';");
            out.print("document.getElementById('msg').innerHTML=msg.fontcolor('red').bold();");
            out.print("</script>");
             RequestDispatcher rd=request.getRequestDispatcher("UpdateBug.jsp");
			rd.include(request, response);
                      
            // out.print("<b>Password has not been changed. Please enter valid old password.</b>");
            //out.print("document.getElementById('msg').innerHTML=msg.fontcolor('red');");
    }
           con.close();
       } 
       catch(Exception e)
       {
           
       }
       
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
